import React, { useState, useEffect, createContext, useContext } from 'react';
import { BrowserRouter, Routes, Route, useLocation, useNavigate, Navigate } from 'react-router';
import { Navbar, Footer } from './components/LayoutElements';
import { Sidebar } from './components/Sidebar';
import { LandingPage } from './components/LandingPage';
import { LoginPage, RegistrationPage } from './components/AuthPages';
import { DashboardHome, ProcessPage } from './components/Dashboard';
import { ComparisonPage, CheckoutPage, ProfilePage, HistoryPage } from './components/ContentPages';
import { Toaster, toast } from 'sonner';

// Authentication Context
const AuthContext = createContext<{
  isAuthenticated: boolean;
  login: () => void;
  logout: () => void;
} | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    // We'll show a toast in a useEffect inside the component or handle it here
    return <Navigate to="/login" state={{ from: location, message: "Please log in to your account to access this feature." }} replace />;
  }

  return <>{children}</>;
};

const AppContent: React.FC = () => {
  const location = useLocation();
  const { isAuthenticated } = useAuth();
  const isDashboard = location.pathname.startsWith('/dashboard');

  useEffect(() => {
    const state = location.state as { message?: string };
    if (state?.message) {
      toast.error(state.message);
    }
  }, [location]);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      <Toaster position="top-center" richColors />
      
      {!isDashboard && <Navbar />}
      
      <div className={`flex flex-1 ${isDashboard ? 'pl-64' : ''}`}>
        {isDashboard && isAuthenticated && <Sidebar />}
        
        <main className={`flex-1 ${isDashboard ? 'p-8 pt-10' : ''}`}>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegistrationPage />} />
            
            {/* Dashboard Routes - Protected */}
            <Route path="/dashboard" element={<ProtectedRoute><DashboardHome /></ProtectedRoute>} />
            <Route path="/dashboard/process" element={<ProtectedRoute><ProcessPage /></ProtectedRoute>} />
            <Route path="/dashboard/comparison" element={<ProtectedRoute><ComparisonPage /></ProtectedRoute>} />
            <Route path="/dashboard/checkout" element={<ProtectedRoute><CheckoutPage /></ProtectedRoute>} />
            <Route path="/dashboard/history" element={<ProtectedRoute><HistoryPage type="processing" /></ProtectedRoute>} />
            <Route path="/dashboard/payments" element={<ProtectedRoute><HistoryPage type="payment" /></ProtectedRoute>} />
            <Route path="/dashboard/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
          </Routes>
        </main>
      </div>
      
      {!isDashboard && <Footer />}
    </div>
  );
};

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Check session on mount
  useEffect(() => {
    const session = localStorage.getItem('isLoggedIn');
    if (session === 'true') setIsAuthenticated(true);
  }, []);

  const login = () => {
    setIsAuthenticated(true);
    localStorage.setItem('isLoggedIn', 'true');
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('isLoggedIn');
  };

  return (
    <BrowserRouter>
      <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
        <AppContent />
      </AuthContext.Provider>
    </BrowserRouter>
  );
};

export default App;
