import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Upload, 
  Image as ImageIcon, 
  Settings2, 
  Sparkles, 
  Download, 
  RefreshCw,
  X,
  CheckCircle2,
  ArrowRight,
  Maximize2
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Link, useNavigate } from 'react-router';
import { toast } from 'sonner';

export const DashboardHome: React.FC = () => {
  const stats = [
    { label: 'Total Images Processed', value: '24', icon: ImageIcon, color: 'bg-indigo-50 text-indigo-600' },
    { label: 'Total Amount Spent', value: '₹420', icon: Sparkles, color: 'bg-purple-50 text-purple-600' },
    { label: 'Favorite Style', value: 'Classic Cartoon', icon: Settings2, color: 'bg-blue-50 text-blue-600' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Welcome back, Janhvi! 👋</h1>
          <p className="text-gray-500">Here's what's happening with your creations today.</p>
        </div>
        <Link 
          to="/dashboard/process"
          className="flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
        >
          <Upload size={18} />
          Upload New Image
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
            <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center mb-4`}>
              <stat.icon size={24} />
            </div>
            <p className="text-sm font-medium text-gray-500 mb-1">{stat.label}</p>
            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
          </div>
        ))}
      </div>

      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900">Recent Creations</h2>
          <Link to="/dashboard/history" className="text-sm font-semibold text-indigo-600 hover:underline">View all history</Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { id: 1, name: 'Urban Sketch Portrait', date: 'Oct 24, 2023', style: 'Sketch', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_JjZuspS7Ob1rwNu4y9hQRe5BRod1zQQBIw&s' },
            { id: 2, name: 'Mountain Classic', date: 'Oct 22, 2023', style: 'Classic Cartoon', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5afw528XlpInUZQ1_twUufHCzPXuTx2i38Q&s' },
            { id: 3, name: 'Neon Vibes Pencil', date: 'Oct 20, 2023', style: 'Pencil Color', img: 'https://imagef2.promeai.pro/process/do/422e213cc06168b2be3a468c309fd7ac.webp?sourceUrl=/g/p/gallery/publish/2024/02/22/a6b113e6613a43a8a2af7894335adf17.png&x-oss-process=image/resize,w_500,h_500/format,webp&sign=99aa0b11ebd6aafc36834b6b891135de' },
            { id: 4, name: 'Vintage Street Style', date: 'Oct 18, 2023', style: 'Sketch', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTJaH7vxjmpafrcw4gB9JoEpA-p4ohvPsowUw&s' },
          ].map((item) => (
            <div key={item.id} className="group relative bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-md transition-all">
              <div className="aspect-square relative overflow-hidden">
                <ImageWithFallback 
                  src={item.img} 
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                   <button className="p-2 bg-white rounded-full text-gray-900 hover:bg-indigo-600 hover:text-white transition-colors">
                     <Maximize2 size={18} />
                   </button>
                   <button className="p-2 bg-white rounded-full text-gray-900 hover:bg-indigo-600 hover:text-white transition-colors">
                     <Download size={18} />
                   </button>
                </div>
                <div className="absolute top-2 left-2 px-2 py-1 bg-white/90 backdrop-blur-sm rounded-lg text-[10px] font-bold text-indigo-600 uppercase tracking-wider">
                  {item.style}
                </div>
              </div>
              <div className="p-4">
                <p className="font-bold text-gray-900 text-sm mb-1">{item.name}</p>
                <p className="text-xs text-gray-500">{item.date}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export const ProcessPage: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processedImage, setProcessedImage] = useState<string | null>(null);
  const [selectedStyle, setSelectedStyle] = useState('Classic Cartoon');
  const navigate = useNavigate();
  
  const styles = [
    { id: 'cartoon', name: 'Classic Cartoon', icon: '🎨' },
    { id: 'sketch', name: 'Sketch', icon: '✏️' },
    { id: 'pencil', name: 'Pencil Color', icon: '🖍️' },
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setPreview(URL.createObjectURL(selectedFile));
      setProcessedImage(null);
    }
  };

  const processImage = () => {
    if (!preview) return;
    setIsProcessing(true);
    // Simulate AI processing with realistic timing
    setTimeout(() => {
      setIsProcessing(false);
      // Instead of a random image, we use the preview but it would be the "processed" one
      // In a real app, this URL would come from the server
      setProcessedImage(preview); 
      toast.success('AI Transformation Complete!');
    }, 2500);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Create Masterpiece</h1>
        <p className="text-gray-500">Upload your photo and let our AI do the magic</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sidebar Settings */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Settings2 size={18} className="text-indigo-600" />
              Settings
            </h3>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">Choose Style</label>
                <div className="grid grid-cols-1 gap-2">
                  {styles.map((style) => (
                    <button
                      key={style.id}
                      onClick={() => setSelectedStyle(style.name)}
                      className={`flex items-center gap-3 p-3 rounded-xl text-sm font-medium border transition-all ${
                        selectedStyle === style.name 
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-sm' 
                        : 'border-gray-100 bg-gray-50 text-gray-500 hover:border-gray-200 hover:bg-white'
                      }`}
                    >
                      <span className="text-xl">{style.icon}</span>
                      {style.name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Edge Intensity</label>
                  <span className="text-xs font-bold text-indigo-600">65%</span>
                </div>
                <input type="range" className="w-full h-1.5 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-indigo-600" />
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Color Strength</label>
                  <span className="text-xs font-bold text-indigo-600">80%</span>
                </div>
                <input type="range" className="w-full h-1.5 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-indigo-600" />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Cartoon Level</label>
                <div className="flex bg-gray-100 p-1 rounded-lg">
                  {['Light', 'Medium', 'Strong'].map((level) => (
                    <button 
                      key={level}
                      className={`flex-1 py-1.5 rounded-md text-xs font-bold transition-all ${
                        level === 'Medium' ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-500 hover:text-gray-700'
                      }`}
                    >
                      {level}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={processImage}
            disabled={!preview || isProcessing}
            className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isProcessing ? (
              <>
                <RefreshCw size={20} className="animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Sparkles size={20} />
                Process Image
              </>
            )}
          </button>
        </div>

        {/* Main Preview Area */}
        <div className="lg:col-span-8 space-y-6">
          {!preview ? (
            <div className="bg-white border-2 border-dashed border-gray-200 rounded-3xl p-12 text-center transition-all hover:border-indigo-300 hover:bg-indigo-50/30 group">
              <input 
                type="file" 
                id="image-upload" 
                className="hidden" 
                onChange={handleFileChange}
                accept=".jpg,.jpeg,.png,.bmp"
              />
              <label htmlFor="image-upload" className="cursor-pointer">
                <div className="w-20 h-20 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <Upload size={40} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Drag & drop your image here</h3>
                <p className="text-gray-500 mb-6">Or click to browse from your computer</p>
                <div className="flex justify-center gap-4 text-xs font-bold text-gray-400 uppercase tracking-widest">
                  <span>JPG</span>
                  <span>PNG</span>
                  <span>BMP</span>
                  <span>MAX 10MB</span>
                </div>
              </label>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="bg-white p-2 rounded-3xl border border-gray-100 shadow-xl relative overflow-hidden">
                <button 
                  onClick={() => {setFile(null); setPreview(null); setProcessedImage(null);}}
                  className="absolute top-4 right-4 z-20 w-8 h-8 bg-black/50 text-white rounded-full flex items-center justify-center hover:bg-black transition-colors"
                >
                  <X size={18} />
                </button>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <div className="relative aspect-square md:aspect-auto md:h-[500px] rounded-2xl overflow-hidden bg-gray-50">
                    <ImageWithFallback src={preview} alt="Original" className="w-full h-full object-contain" />
                    <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-lg text-xs font-bold text-gray-900 shadow-sm">
                      ORIGINAL
                    </div>
                  </div>
                  
                  <div className="relative aspect-square md:aspect-auto md:h-[500px] rounded-2xl overflow-hidden bg-gray-50 border border-gray-100">
                    {processedImage ? (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="w-full h-full relative"
                      >
                        <ImageWithFallback 
                          src={processedImage} 
                          alt="Processed" 
                          className={`w-full h-full object-contain transition-all duration-700 ${
                            selectedStyle === 'Sketch' ? 'grayscale contrast-125 brightness-110 invert-[0.1]' : 
                            selectedStyle === 'Pencil Color' ? 'saturate-200 contrast-110 sepia-[0.2]' : 
                            'saturate-150 contrast-125'
                          }`} 
                        />
                        <div className="absolute inset-0 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/paper.png')] opacity-30"></div>
                        <div className="absolute top-4 left-4 bg-indigo-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm">
                          {selectedStyle.toUpperCase()} APPLIED
                        </div>
                      </motion.div>
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-gray-400 space-y-3">
                        {isProcessing ? (
                          <div className="flex flex-col items-center gap-4">
                            <div className="w-12 h-12 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin" />
                            <p className="text-sm font-medium animate-pulse">AI is dreaming...</p>
                          </div>
                        ) : (
                          <>
                            <ImageIcon size={48} className="opacity-20" />
                            <p className="text-sm font-medium">Processed result will appear here</p>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {processedImage && (
                <div className="flex flex-wrap items-center justify-center gap-4">
                  <button 
                    onClick={() => setProcessedImage(null)}
                    className="px-6 py-3 bg-white border border-gray-200 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all flex items-center gap-2"
                  >
                    <RefreshCw size={18} />
                    Try Another Style
                  </button>
                  <Link 
                    to="/dashboard/comparison"
                    state={{ original: preview, processed: processedImage, style: selectedStyle }}
                    className="px-6 py-3 bg-white border border-gray-200 text-indigo-600 rounded-xl font-bold hover:bg-indigo-50 transition-all flex items-center gap-2"
                  >
                    <Maximize2 size={18} />
                    View Comparison
                  </Link>
                  <Link 
                    to="/dashboard/checkout"
                    state={{ image: processedImage, style: selectedStyle }}
                    className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center gap-2"
                  >
                    <Download size={18} />
                    Download Full Quality
                  </Link>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
