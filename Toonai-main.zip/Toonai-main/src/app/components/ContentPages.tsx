import React, { useState } from 'react';
import { useLocation, Link, useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { 
  ArrowLeft, 
  Download, 
  Share2, 
  Maximize2, 
  ChevronRight, 
  CreditCard, 
  CheckCircle2, 
  FileText,
  Clock,
  ExternalLink,
  ChevronLeft,
  Settings2,
  ShieldCheck,
  Lock,
  Image as ImageIcon
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { toast } from 'sonner';

export const ComparisonPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { original, processed, style } = location.state || { 
    original: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=800&h=800&fit=crop", 
    processed: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=800&h=800&fit=crop",
    style: "Classic Cartoon"
  };

  const [sliderPos, setSliderPos] = useState(50);

  // Define filter classes based on style
  const getFilterClass = (s: string) => {
    switch (s) {
      case 'Sketch': return 'grayscale contrast-125 brightness-110 invert-[0.1]';
      case 'Pencil Color': return 'saturate-200 contrast-110 sepia-[0.2]';
      default: return 'saturate-150 contrast-125';
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-gray-500 hover:text-indigo-600 transition-colors font-medium"
        >
          <ArrowLeft size={18} />
          Back to Processing
        </button>
        <div className="flex gap-3">
          <button className="p-2 bg-white border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50 transition-colors">
            <Share2 size={18} />
          </button>
          <Link 
            to="/dashboard/checkout"
            state={{ image: processed, style }}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 transition-all shadow-sm"
          >
            <Download size={18} />
            Download Transformation
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3 space-y-6">
          <div className="bg-white p-2 rounded-3xl border border-gray-100 shadow-xl overflow-hidden">
            <div className="relative aspect-video md:aspect-auto md:h-[600px] rounded-2xl overflow-hidden select-none touch-none bg-gray-50">
              <ImageWithFallback src={processed} alt="After" className={`absolute inset-0 w-full h-full object-contain ${getFilterClass(style)}`} />
              <div 
                className="absolute inset-0 w-full h-full overflow-hidden z-10" 
                style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}
              >
                <ImageWithFallback src={original} alt="Before" className="absolute inset-0 w-full h-full object-contain" />
              </div>
              
              <div 
                className="absolute top-0 bottom-0 w-1 bg-white shadow-2xl cursor-ew-resize z-30"
                style={{ left: `${sliderPos}%` }}
              >
                <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-10 h-10 bg-white rounded-full shadow-2xl flex items-center justify-center border-4 border-indigo-600">
                  <div className="flex gap-0.5">
                    <ChevronLeft size={14} className="text-indigo-600" />
                    <ChevronRight size={14} className="text-indigo-600" />
                  </div>
                </div>
              </div>

              <input 
                type="range" 
                min="0" 
                max="100" 
                value={sliderPos} 
                onChange={(e) => setSliderPos(parseInt(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-40"
              />

              <div className="absolute top-6 left-6 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-xl text-xs font-bold text-gray-900 shadow-xl z-20">
                ORIGINAL PHOTO
              </div>
              <div className="absolute top-6 right-6 bg-indigo-600 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-xl z-20">
                AI TRANSFORM: {style.toUpperCase()}
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <h3 className="font-bold text-gray-900 mb-6">Metadata</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-500 font-medium">Dimensions</span>
                <span className="text-gray-900 font-bold tracking-tight">2048 x 2048 px</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-500 font-medium">File Size</span>
                <span className="text-gray-900 font-bold tracking-tight">2.4 MB</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-500 font-medium">Format</span>
                <span className="text-gray-900 font-bold tracking-tight">PNG (Lossless)</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-500 font-medium">AI Processing Time</span>
                <span className="text-gray-900 font-bold tracking-tight">1.8s</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-500 font-medium">AI Model</span>
                <span className="text-gray-900 font-bold tracking-tight">NeuralStylize v2.4</span>
              </div>
            </div>
          </div>

          <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
            <h4 className="text-indigo-900 font-bold text-sm mb-2">Pro Tip</h4>
            <p className="text-indigo-700 text-xs leading-relaxed">
              Use the slider to see how AI preserved your facial features while applying the "{style}" effect.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export const CheckoutPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { image, style } = location.state || { image: "https://images.unsplash.com/photo-1733004441442-c3bf86d6e6f7", style: "Classic Cartoon" };
  
  const [step, setStep] = useState<'checkout' | 'success' | 'failure'>('checkout');
  const [quality, setQuality] = useState<'standard' | 'high'>('high');
  const [format, setFormat] = useState('PNG');

  const handlePayment = () => {
    // Simulate payment
    toast.info('Opening payment gateway...');
    setTimeout(() => {
      setStep('success');
      toast.success('Payment successful!');
    }, 2000);
  };

  if (step === 'success') {
    return (
      <div className="max-w-2xl mx-auto py-12 text-center">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white p-10 rounded-3xl shadow-2xl border border-gray-100"
        >
          <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 size={48} />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Payment Successful!</h1>
          <p className="text-gray-500 mb-8">Your transaction ID: <span className="font-bold text-gray-900">TXN_849204820</span></p>
          
          <div className="bg-gray-50 p-6 rounded-2xl mb-8 flex items-center gap-6 text-left">
            <div className="w-24 h-24 rounded-xl overflow-hidden flex-shrink-0 relative">
              <ImageWithFallback 
                src={image} 
                alt="Final" 
                className={`w-full h-full object-cover ${
                  style === 'Sketch' ? 'grayscale contrast-125 brightness-110' : 
                  style === 'Pencil Color' ? 'saturate-200 contrast-110' : 
                  'saturate-150 contrast-125'
                }`} 
              />
            </div>
            <div>
              <h3 className="font-bold text-gray-900">{style} - Ultra HD</h3>
              <p className="text-sm text-gray-500 mb-2">Transaction ID: TXN_849204820</p>
              <div className="flex gap-2">
                <span className="px-2 py-0.5 bg-indigo-100 text-indigo-700 rounded text-[10px] font-bold uppercase tracking-wider">PNG</span>
                <span className="px-2 py-0.5 bg-indigo-100 text-indigo-700 rounded text-[10px] font-bold uppercase tracking-wider">4K READY</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <button className="flex items-center justify-center gap-2 py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
              <Download size={18} />
              Download Image
            </button>
            <button className="flex items-center justify-center gap-2 py-4 bg-white border border-gray-200 text-gray-700 rounded-xl font-bold hover:bg-gray-50 transition-all">
              <FileText size={18} />
              Download Receipt
            </button>
          </div>
          
          <button 
            onClick={() => navigate('/dashboard')}
            className="mt-8 text-sm font-semibold text-gray-500 hover:text-indigo-600 transition-colors"
          >
            Return to Dashboard
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div className="flex items-center gap-4 mb-2">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-2xl font-bold text-gray-900">Checkout</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
            <h3 className="font-bold text-gray-900 mb-6 flex items-center gap-2">
              <Settings2 size={18} className="text-indigo-600" />
              Download Options
            </h3>
            
            <div className="space-y-8">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-4">Select Quality</label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button 
                    onClick={() => setQuality('standard')}
                    className={`p-4 rounded-2xl border-2 text-left transition-all ${
                      quality === 'standard' ? 'border-indigo-600 bg-indigo-50/50' : 'border-gray-100 hover:border-gray-200'
                    }`}
                  >
                    <div className="flex justify-between mb-2">
                      <span className="font-bold text-gray-900">Standard</span>
                      <span className="font-bold text-gray-900">₹10</span>
                    </div>
                    <p className="text-xs text-gray-500 leading-relaxed">Perfect for social media and web. Standard resolution (720p).</p>
                  </button>
                  <button 
                    onClick={() => setQuality('high')}
                    className={`p-4 rounded-2xl border-2 text-left transition-all ${
                      quality === 'high' ? 'border-indigo-600 bg-indigo-50/50' : 'border-gray-100 hover:border-gray-200'
                    }`}
                  >
                    <div className="flex justify-between mb-2">
                      <span className="font-bold text-gray-900">High-Quality</span>
                      <span className="font-bold text-indigo-600">₹50</span>
                    </div>
                    <p className="text-xs text-gray-500 leading-relaxed">Ultra-high resolution (4K) with commercial usage license.</p>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-4">Select Format</label>
                <div className="flex flex-wrap gap-3">
                  {['PNG', 'JPG', 'PDF'].map(f => (
                    <button 
                      key={f}
                      onClick={() => setFormat(f)}
                      className={`px-6 py-2.5 rounded-xl text-sm font-bold border transition-all ${
                        format === f ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-500 border-gray-200 hover:border-indigo-200'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
            <h3 className="font-bold text-gray-900 mb-6 flex items-center gap-2">
              <CreditCard size={18} className="text-indigo-600" />
              Payment Information
            </h3>
            <div className="p-12 border-2 border-dashed border-gray-100 rounded-2xl flex flex-col items-center justify-center text-center">
              <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-4 text-gray-400">
                <CreditCard size={32} />
              </div>
              <p className="text-sm font-medium text-gray-500">Razorpay gateway will open in a secure window</p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-xl sticky top-8">
            <h3 className="font-bold text-gray-900 mb-6">Order Summary</h3>
            <div className="aspect-square rounded-2xl overflow-hidden mb-6 relative">
              <ImageWithFallback 
                src={image} 
                alt="Preview" 
                className={`w-full h-full object-cover ${
                  style === 'Sketch' ? 'grayscale contrast-125 brightness-110' : 
                  style === 'Pencil Color' ? 'saturate-200 contrast-110' : 
                  'saturate-150 contrast-125'
                }`} 
              />
              <div className="absolute inset-0 bg-black/10 pointer-events-none"></div>
            </div>
            
            <div className="space-y-4 mb-6">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Style Applied</span>
                <span className="text-gray-900 font-bold">{style}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Download Quality</span>
                <span className="text-gray-900 font-bold">{quality === 'high' ? 'Ultra HD (4K)' : 'Standard (720p)'}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">File Format</span>
                <span className="text-gray-900 font-bold">{format}</span>
              </div>
            </div>
            
            <div className="pt-6 border-t border-gray-100 mb-8">
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold text-gray-900">Total Price</span>
                <span className="text-2xl font-extrabold text-indigo-600 tracking-tight">₹{quality === 'high' ? '$10' : '$5'}</span>
              </div>
            </div>

            <button 
              onClick={handlePayment}
              className="w-full py-4 bg-indigo-600 text-white rounded-xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 active:scale-[0.98]"
            >
              Proceed to Payment
            </button>
            <p className="text-center mt-4 text-[10px] text-gray-400 uppercase tracking-widest font-bold flex items-center justify-center gap-1">
              <ShieldCheck size={12} />
              Secure Checkout Powered by Razorpay
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export const ProfilePage: React.FC = () => {
  return (
    <div className="max-w-4xl space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Profile Settings</h1>
        <p className="text-gray-500">Manage your account information and preferences.</p>
      </div>

      <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
        <div className="flex items-center gap-6 mb-10">
          <div className="w-24 h-24 bg-indigo-100 rounded-3xl flex items-center justify-center text-indigo-600 text-3xl font-bold relative">
            AJ
            <button className="absolute -bottom-2 -right-2 w-8 h-8 bg-white border border-gray-200 rounded-full flex items-center justify-center text-gray-600 shadow-sm hover:text-indigo-600">
              <ImageIcon size={16} />
            </button>
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-900">Alex Johnson</h3>
            <p className="text-gray-500">Member since October 2023</p>
            <div className="flex gap-2 mt-2">
              <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded text-[10px] font-bold uppercase tracking-wider">Premium Account</span>
            </div>
          </div>
        </div>

        <form className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Username</label>
            <input 
              type="text" 
              defaultValue="alexjohnson"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Email Address</label>
            <input 
              type="email" 
              defaultValue="alex@example.com"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Full Name</label>
            <input 
              type="text" 
              defaultValue="Alex Johnson"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Timezone</label>
            <select className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500">
              <option>India (GMT +5:30)</option>
              <option>UTC (GMT +0:00)</option>
            </select>
          </div>
        </form>

        <div className="mt-10 pt-10 border-t border-gray-100 flex justify-end">
          <button className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all">
            Save Changes
          </button>
        </div>
      </div>

      <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
        <h3 className="font-bold text-gray-900 mb-6 flex items-center gap-2">
          <Lock size={18} className="text-indigo-600" />
          Security
        </h3>
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
          <div>
            <p className="font-bold text-gray-900">Change Password</p>
            <p className="text-sm text-gray-500">Update your account password regularly for better security.</p>
          </div>
          <button className="px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-lg font-bold text-sm hover:bg-gray-50 transition-colors">
            Update
          </button>
        </div>
      </div>
    </div>
  );
};

export const HistoryPage: React.FC<{ type: 'processing' | 'payment' }> = ({ type }) => {
  const processingHistory = [
    { id: 1, name: 'Alex Profile Cartoon', style: 'Classic Cartoon', date: 'Oct 24, 2023', status: 'Paid', img: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop' },
    { id: 2, name: 'Vacation Sketch', style: 'Sketch', date: 'Oct 22, 2023', status: 'Paid', img: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&h=400&fit=crop' },
    { id: 3, name: 'Family Portrait Pencil', style: 'Pencil Color', date: 'Oct 20, 2023', status: 'Paid', img: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=400&fit=crop' },
    { id: 4, name: 'Corporate Headshot', style: 'Classic Cartoon', date: 'Oct 18, 2023', status: 'Paid', img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop' },
    { id: 5, name: 'Pet Sketch', style: 'Sketch', date: 'Oct 15, 2023', status: 'Paid', img: 'https://images.unsplash.com/photo-1450778869180-41d0601e046e?w=400&h=400&fit=crop' },
    { id: 6, name: 'Nature Landscape', style: 'Classic Cartoon', date: 'Oct 12, 2023', status: 'Paid', img: 'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?w=400&h=400&fit=crop' },
    { id: 7, name: 'Urban Exploration', style: 'Sketch', date: 'Oct 10, 2023', status: 'Paid', img: 'https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=400&h=400&fit=crop' },
    { id: 8, name: 'Sunset Pencil', style: 'Pencil Color', date: 'Oct 05, 2023', status: 'Paid', img: 'https://images.unsplash.com/photo-1501183007986-d0d080b147f9?w=400&h=400&fit=crop' },
  ];

  const paymentHistory = [
    { id: 'TXN_982401', amount: '₹50', method: 'Razorpay (UPI)', date: 'Oct 24, 2023', status: 'Success' },
    { id: 'TXN_982402', amount: '₹10', method: 'Razorpay (Card)', date: 'Oct 22, 2023', status: 'Success' },
    { id: 'TXN_982403', amount: '₹50', method: 'Razorpay (UPI)', date: 'Oct 20, 2023', status: 'Success' },
    { id: 'TXN_982404', amount: '₹50', method: 'Razorpay (Net Banking)', date: 'Oct 18, 2023', status: 'Success' },
    { id: 'TXN_982405', amount: '₹10', method: 'Razorpay (UPI)', date: 'Oct 15, 2023', status: 'Success' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            {type === 'processing' ? 'Creation History' : 'Transaction History'}
          </h1>
          <p className="text-gray-500">
            {type === 'processing' 
              ? 'Access and download your previous AI-transformed masterpieces.' 
              : 'Detailed record of your payments and usage credits.'}
          </p>
        </div>
        <div className="flex gap-2">
          <select className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500">
            <option>All Creations</option>
            <option>Classic Cartoon</option>
            <option>Sketch</option>
            <option>Pencil Color</option>
          </select>
          <select className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500">
            <option>October 2023</option>
            <option>September 2023</option>
            <option>Last 6 months</option>
          </select>
        </div>
      </div>

      {type === 'processing' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {processingHistory.map(item => (
            <div key={item.id} className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-md transition-all group">
              <div className="aspect-square relative overflow-hidden">
                <ImageWithFallback 
                  src={item.img} 
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 right-3">
                   <span className="px-2 py-1 bg-green-500 text-white rounded-lg text-[10px] font-bold uppercase tracking-wider shadow-sm">{item.status}</span>
                </div>
              </div>
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-bold text-gray-900 text-sm truncate pr-2">{item.name}</h4>
                  <p className="text-[9px] font-extrabold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded whitespace-nowrap">{item.style.toUpperCase()}</p>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-4">
                  <Clock size={12} />
                  {item.date}
                </div>
                <button className="w-full py-2 bg-gray-50 text-gray-700 rounded-lg text-xs font-bold hover:bg-indigo-600 hover:text-white transition-all flex items-center justify-center gap-2">
                  <Download size={14} />
                  Download 4K
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Transaction Ref</th>
                  <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Amount Paid</th>
                  <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Method</th>
                  <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Date</th>
                  <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Status</th>
                  <th className="px-6 py-4 text-right"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {paymentHistory.map(payment => (
                  <tr key={payment.id} className="hover:bg-gray-50/50 transition-colors">
                    <td className="px-6 py-4 text-sm font-bold text-gray-900">{payment.id}</td>
                    <td className="px-6 py-4 text-sm font-bold text-indigo-600">{payment.amount}</td>
                    <td className="px-6 py-4 text-sm text-gray-500">{payment.method}</td>
                    <td className="px-6 py-4 text-sm text-gray-500">{payment.date}</td>
                    <td className="px-6 py-4">
                      <span className="px-2 py-1 bg-green-50 text-green-600 rounded-lg text-[10px] font-bold uppercase tracking-wider">{payment.status}</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="text-gray-400 hover:text-indigo-600 transition-colors" title="Download Invoice">
                        <FileText size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="p-6 border-t border-gray-100 flex justify-center">
            <div className="flex gap-2">
              <button className="w-10 h-10 flex items-center justify-center rounded-lg border border-gray-200 text-gray-500 disabled:opacity-50" disabled>
                <ChevronLeft size={18} />
              </button>
              <button className="w-10 h-10 flex items-center justify-center rounded-lg bg-indigo-600 text-white font-bold">1</button>
              <button className="w-10 h-10 flex items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-50">2</button>
              <button className="w-10 h-10 flex items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-50">3</button>
              <button className="w-10 h-10 flex items-center justify-center rounded-lg border border-gray-200 text-gray-500">
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

