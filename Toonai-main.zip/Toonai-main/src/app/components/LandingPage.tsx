import React from 'react';
import { Link } from 'react-router';
import { motion } from 'motion/react';
import { useAuth } from '../App';
import { 
  ShieldCheck, 
  Palette, 
  Zap, 
  Download, 
  CheckCircle2, 
  ArrowRight,
  Star
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export const LandingPage: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const features = [
    {
      icon: ShieldCheck,
      title: "Secure Authentication",
      desc: "Your photos and data are protected with industry-standard encryption."
    },
    {
      icon: Palette,
      title: "Multiple Artistic Styles",
      desc: "Choose from Classic Cartoon, Sketch, Pencil Color, and more styles."
    },
    {
      icon: Zap,
      title: "Instant Image Preview",
      desc: "See your transformations in real-time before you commit to download."
    },
    {
      icon: Download,
      title: "Secure Payments & Downloads",
      desc: "Flexible pricing plans with high-quality processed image downloads."
    }
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-white py-20 lg:py-32">
        <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-[600px] h-[600px] bg-indigo-50 rounded-full blur-3xl opacity-50" />
        <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-purple-50 rounded-full blur-3xl opacity-50" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-5xl lg:text-7xl font-bold text-gray-900 leading-[1.1] mb-6">
                Transform Your Photos into <span className="text-indigo-600">Stunning Cartoon Art</span>
              </h1>
              <p className="text-xl text-gray-600 mb-10 leading-relaxed max-w-lg">
                AI-powered image stylization using advanced computer vision techniques. Turn your memories into unique artistic masterpieces in seconds.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link 
                  to={isAuthenticated ? "/dashboard/process" : "/register"} 
                  className="px-8 py-4 bg-indigo-600 text-white rounded-full font-bold text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200 flex items-center gap-2 group"
                >
                  {isAuthenticated ? "Process New Image" : "Get Started"}
                  <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                </Link>
                {!isAuthenticated && (
                  <Link 
                    to="/login" 
                    className="px-8 py-4 bg-white border border-gray-200 text-gray-900 rounded-full font-bold text-lg hover:bg-gray-50 transition-all shadow-sm"
                  >
                    Login
                  </Link>
                )}
                {isAuthenticated && (
                  <Link 
                    to="/dashboard" 
                    className="px-8 py-4 bg-white border border-gray-200 text-gray-900 rounded-full font-bold text-lg hover:bg-gray-50 transition-all shadow-sm"
                  >
                    Go to Dashboard
                  </Link>
                )}
              </div>
              <div className="mt-10 flex items-center gap-4 text-sm text-gray-500">
                <div className="flex -space-x-2">
                  {[1,2,3,4].map(i => (
                    <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-gray-200 overflow-hidden">
                       <ImageWithFallback 
                        src={`https://images.unsplash.com/photo-${1633332755192 + i}-72af6742f585?w=100&h=100&fit=crop`} 
                        alt="User"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-1">
                  <Star className="text-yellow-400 fill-yellow-400" size={16} />
                  <span className="font-semibold text-gray-900">4.9/5</span>
                  <span>from 10k+ creators</span>
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="relative z-10 bg-white p-4 rounded-3xl shadow-2xl border border-gray-100 transform rotate-2">
                <div className="relative aspect-[4/5] rounded-2xl overflow-hidden group">
                  <ImageWithFallback 
                    src="https://images.unsplash.com/photo-1636936291087-2972edf08f14" 
                    alt="Original vs Cartoon"
                    className="w-full h-full object-cover"
                  />
                  {/* Mock comparison slider handle */}
                  <div className="absolute top-0 left-1/2 bottom-0 w-1 bg-white shadow-lg cursor-ew-resize flex items-center justify-center">
                    <div className="w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center -ml-0.5 border border-indigo-100">
                      <Zap size={16} className="text-indigo-600" />
                    </div>
                  </div>
                  <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full text-xs font-bold text-gray-900 shadow-sm uppercase tracking-wider">
                    Original
                  </div>
                  <div className="absolute top-4 right-4 bg-indigo-600/90 backdrop-blur-sm px-3 py-1.5 rounded-full text-xs font-bold text-white shadow-sm uppercase tracking-wider">
                    AI Cartoon
                  </div>
                </div>
              </div>
              {/* Decorative elements */}
              <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-purple-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob" />
              <div className="absolute -top-6 -right-6 w-32 h-32 bg-indigo-200 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Powerful AI Features</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Everything you need to turn your photos into digital art with just a single click.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, idx) => (
              <div key={idx} className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 mb-6">
                  <feature.icon size={24} />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed text-sm">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Simple, Transparent Pricing</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Pay only for what you need. No hidden subscriptions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="bg-white p-10 rounded-3xl border border-gray-100 shadow-xl relative overflow-hidden group hover:border-indigo-200 transition-colors">
              <div className="absolute top-0 right-0 p-8 opacity-5">
                <Download size={120} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Standard Download</h3>
              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-4xl font-extrabold text-gray-900">$3</span>
                <span className="text-gray-500">/image</span>
              </div>
              <ul className="space-y-4 mb-10">
                <li className="flex items-center gap-3 text-gray-600">
                  <CheckCircle2 size={18} className="text-green-500" />
                  Standard resolution (720p)
                </li>
                <li className="flex items-center gap-3 text-gray-600">
                  <CheckCircle2 size={18} className="text-green-500" />
                  Web-optimized format
                </li>
                <li className="flex items-center gap-3 text-gray-600">
                  <CheckCircle2 size={18} className="text-green-500" />
                  Classic styles included
                </li>
              </ul>
              <Link 
                to={isAuthenticated ? "/dashboard/process" : "/register"} 
                className="block w-full text-center py-4 bg-gray-900 text-white rounded-xl font-bold hover:bg-gray-800 transition-colors"
              >
                Choose Standard
              </Link>
            </div>

            <div className="bg-white p-10 rounded-3xl border-2 border-indigo-600 shadow-2xl relative overflow-hidden ring-4 ring-indigo-50">
              <div className="absolute top-0 right-0 bg-indigo-600 text-white px-4 py-1 text-xs font-bold uppercase tracking-widest rounded-bl-xl">
                Popular
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">High-Quality Download</h3>
              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-4xl font-extrabold text-gray-900">$5</span>
                <span className="text-gray-500">/image</span>
              </div>
              <ul className="space-y-4 mb-10">
                <li className="flex items-center gap-3 text-gray-600">
                  <CheckCircle2 size={18} className="text-indigo-600" />
                  Ultra HD resolution (4K)
                </li>
                <li className="flex items-center gap-3 text-gray-600">
                  <CheckCircle2 size={18} className="text-indigo-600" />
                  No watermark
                </li>
                <li className="flex items-center gap-3 text-gray-600">
                  <CheckCircle2 size={18} className="text-indigo-600" />
                  All premium styles
                </li>
                <li className="flex items-center gap-3 text-gray-600">
                  <CheckCircle2 size={18} className="text-indigo-600" />
                  Commercial usage license
                </li>
              </ul>
              <Link 
                to={isAuthenticated ? "/dashboard/process" : "/register"} 
                className="block w-full text-center py-4 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200"
              >
                Go Premium
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-indigo-600 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-64 h-64 bg-white rounded-full blur-3xl" />
        </div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl lg:text-5xl font-bold text-white mb-6">Ready to cartoonize your world?</h2>
          <p className="text-xl text-indigo-100 mb-10 leading-relaxed">
            Join thousands of users who are already creating amazing AI art from their everyday photos.
          </p>
          <Link 
            to={isAuthenticated ? "/dashboard/process" : "/register"} 
            className="inline-flex items-center gap-2 px-10 py-5 bg-white text-indigo-600 rounded-full font-bold text-xl hover:bg-indigo-50 transition-all shadow-xl"
          >
            {isAuthenticated ? "Process Another Image" : "Create Your Account Now"}
            <ArrowRight />
          </Link>
        </div>
      </section>
    </div>
  );
};
